#ifndef __MESSAGE_H

typedef struct {
    int lowerBound;
    int upperBound;
    int guess;
} MESSAGE;

#endif
